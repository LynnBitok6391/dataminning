"""
Explains HOW the model works using real students from the test set.
Fast (a few seconds). Run after student_performance_analysis.py:  python explain_model.py
Writes outputs/explain.json, which build_dashboard.py shows on the "How it works" page.
Uses the same cleaning, the same 80/20 split and the same seed (42) as the main analysis.
"""
import json
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import r2_score, mean_squared_error

df = pd.read_csv("data/student_habits_performance.csv")
df["parental_education_level"] = df["parental_education_level"].fillna("Not reported")
df = df.drop(columns="student_id")
num = ["age","study_hours_per_day","social_media_hours","netflix_hours","attendance_percentage",
       "sleep_hours","exercise_frequency","mental_health_rating"]
cat = ["gender","part_time_job","diet_quality","parental_education_level","internet_quality","extracurricular_participation"]
X, y = df.drop(columns="exam_score"), df["exam_score"]
make_pre = lambda: ColumnTransformer([("c", OneHotEncoder(handle_unknown="ignore", drop="first"), cat),
                                      ("n", StandardScaler(), num)])
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.20, random_state=42)   # same split as the main script

lin = Pipeline([("p", make_pre()), ("m", LinearRegression())]).fit(Xtr, ytr)
pred = lin.predict(Xte)
rmse = lambda p: float(np.sqrt(mean_squared_error(yte, p)))

# Six real test students: the model never saw their scores
rows = []
for i in range(6):
    r = Xte.iloc[i]
    rows.append({"study": float(r.study_hours_per_day), "mental": int(r.mental_health_rating),
                 "attend": float(r.attendance_percentage), "actual": round(float(yte.iloc[i]), 1),
                 "pred": round(float(pred[i]), 1), "err": round(float(pred[i] - yte.iloc[i]), 1)})

# Marks gained per one extra unit = scaled coefficient / the factor's spread (std)
names = lin.named_steps["p"].get_feature_names_out()
coef = pd.Series(lin.named_steps["m"].coef_, index=names)
scale = dict(zip(num, lin.named_steps["p"].named_transformers_["n"].scale_))
effects = {n: round(float(coef["n__" + n] / scale[n]), 3) for n in num}

ridge = []
for a in [1, 100, 1000, 5000]:
    rp = Pipeline([("p", make_pre()), ("m", Ridge(alpha=a))]).fit(Xtr, ytr).predict(Xte)
    ridge.append({"alpha": a, "r2": round(r2_score(yte, rp), 4), "rmse": round(rmse(rp), 2)})
r1 = Pipeline([("p", make_pre()), ("m", Ridge(alpha=1))]).fit(Xtr, ytr)
out = {"train": len(Xtr), "test": len(Xte), "overlap": len(set(Xtr.index) & set(Xte.index)),
       "rows": rows, "intercept": round(float(lin.named_steps["m"].intercept_), 1), "effects": effects,
       "ridge": ridge, "lin_r2": round(r2_score(yte, pred), 4), "lin_rmse": round(rmse(pred), 2),
       "max_coef_diff": round(float(np.abs(r1.named_steps["m"].coef_ - lin.named_steps["m"].coef_).max()), 3)}
json.dump(out, open("outputs/explain.json", "w"), indent=2)
print(json.dumps(out, indent=2))
